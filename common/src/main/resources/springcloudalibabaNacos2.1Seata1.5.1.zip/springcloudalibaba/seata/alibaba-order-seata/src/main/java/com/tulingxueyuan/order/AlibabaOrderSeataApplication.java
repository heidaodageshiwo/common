package com.tulingxueyuan.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/***
 * @Author 徐庶   QQ:1092002729
 * @Slogan 致敬大师，致敬未来的你
 */
@SpringBootApplication
//@EnableTransactionManagement     // 开启本地事务@Transactional
@EnableFeignClients
public class AlibabaOrderSeataApplication {

    public static void main(String[] args) {
        try {
            SpringApplication.run(AlibabaOrderSeataApplication.class,args);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

    }


}

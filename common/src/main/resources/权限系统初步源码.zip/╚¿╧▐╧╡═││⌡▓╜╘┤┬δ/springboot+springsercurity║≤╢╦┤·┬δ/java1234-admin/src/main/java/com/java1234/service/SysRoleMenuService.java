package com.java1234.service;

import com.java1234.entity.SysRoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author java1234
* @description 针对表【sys_role_menu】的数据库操作Service
* @createDate 2022-07-05 08:25:44
*/
public interface SysRoleMenuService extends IService<SysRoleMenu> {

}

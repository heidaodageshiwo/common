<template>
  <div class="footer">
    Copyright © 2012-2022 Java知识分享网 版权所有&nbsp;&nbsp;<a href="http://www.java1234.vip" target="_blank">www.java1234.vip</a>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>
.footer{
  padding: 20px;
  display: flex;
  align-items: center;
}
</style>
